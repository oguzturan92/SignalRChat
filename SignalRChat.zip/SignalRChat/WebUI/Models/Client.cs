using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebUI.Models
{
    public class Client
    {
        public string ConnectionId { get; set; }
        public string NickName { get; set; }
    }
}