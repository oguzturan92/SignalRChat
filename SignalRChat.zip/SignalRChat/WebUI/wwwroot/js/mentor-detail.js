
// var point1 = document.getElementById("point1");
// var point2 = document.getElementById("point2");
// var point3 = document.getElementById("point3");
// var point4 = document.getElementById("point4");
// var point5 = document.getElementById("point5");

// point2.addEventListener("mouseenter", function (event) {
//     point2.style.color = "#e7e7e7";
//     point3.style.color = "#e7e7e7";
//     point4.style.color = "#e7e7e7";
//     point5.style.color = "#e7e7e7";
//     event.preventDefault();
// });