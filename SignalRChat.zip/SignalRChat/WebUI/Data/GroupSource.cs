using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebUI.Models;

namespace WebUI.Data
{
    public class GroupSource
    {
        public static List<Group> Groups { get; } = new List<Group>();
    }
}